// gameflow.jsx
// Game-flow state screens (Pause, Round Complete, Run Complete) + Settings comps.
// All game-flow states shown in Full Bleed skin (default).
// Settings shown in all three skins.

// ─── Shell frame (board + HUD behind overlay) ─────────────────────────────
function GameShellFrame({ skin, phone, boardOpacity = 0.22, children }) {
  const boardCols = phone ? 7 : 10;
  const cellSize = phone ? 36 : 42;
  const rows = FAKE_BOARD_ROWS.slice(0, 8).map(r => r.slice(0, boardCols));
  const path = FAKE_PATH_CELLS.filter(([, c]) => c < boardCols);

  return (
    <div style={{
      ...skin.vars,
      position: 'relative', width: '100%', height: '100%',
      overflow: 'hidden', background: 'var(--bg)', color: 'var(--ink)',
      fontFamily: 'var(--font-body)', display: 'flex', flexDirection: 'column',
    }}>
      <skin.Background />
      <div style={{ position: 'relative', zIndex: 1, display: 'flex', flexDirection: 'column', height: '100%' }}>
        <FakeHUD skin={skin} phone={phone} menuOpen={false} />
        <div style={{ flex: 1, display: 'flex', minHeight: 0, position: 'relative' }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <MiniBoard skin={skin} cellSize={cellSize} rows={rows} path={path} opacity={boardOpacity} />
          </div>
          {!phone && <FakeRightRail skin={skin} />}
        </div>
        <FakeActionBar skin={skin} phone={phone} />

        {/* Overlay */}
        <div style={{
          position: 'absolute', inset: 0, zIndex: 10,
          background: 'rgba(0,0,0,.65)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          backdropFilter: 'blur(3px)',
        }}>
          {children}
        </div>
      </div>
    </div>
  );
}

// ─── Shared card shell ────────────────────────────────────────────────────
function FlowCard({ skin, phone, width, children }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  const w = width || (phone ? 300 : 400);

  return (
    <div style={{
      width: w,
      background: isPage
        ? 'radial-gradient(ellipse at 30% 20%, #f9f0d8 0%, #f3e9d2 55%, #e8dcbe 100%)'
        : isTerm ? '#0a0d09' : '#12141a',
      border: isPage ? '1px solid rgba(200,152,72,.5)' : (isTerm ? '1px solid #7fdb6a' : '1px solid rgba(255,255,255,.09)'),
      boxShadow: '0 12px 48px rgba(0,0,0,.75)',
      borderRadius: isTerm ? 0 : 4,
      padding: phone ? '20px 20px' : '26px 30px',
      position: 'relative', overflow: 'hidden',
    }}>
      {isTerm && (
        <div style={{ position: 'absolute', inset: 0, background: 'repeating-linear-gradient(to bottom, transparent 0px, transparent 2px, rgba(0,0,0,.12) 2px, rgba(0,0,0,.12) 3px)', opacity: .5, pointerEvents: 'none' }} />
      )}
      <div style={{ position: 'relative', zIndex: 1 }}>{children}</div>
    </div>
  );
}

// ─── Flow card header ─────────────────────────────────────────────────────
function FlowHeader({ skin, eyebrow, title, divider = true }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';

  return (
    <div style={{ marginBottom: 18 }}>
      {eyebrow && (
        <div style={{
          fontFamily: isTerm ? 'var(--font-mono)' : '"Inter Tight",sans-serif',
          fontSize: isTerm ? 11 : 9,
          fontWeight: 700,
          color: isTerm ? 'rgba(127,219,106,.5)' : (isPage ? 'rgba(116,40,24,.45)' : 'rgba(212,168,74,.55)'),
          letterSpacing: '0.2em', textTransform: 'uppercase',
          marginBottom: isPage ? 0 : 5,
        }}>{isTerm ? `// ${eyebrow}` : eyebrow}</div>
      )}
      {isTerm ? (
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color: '#7fdb6a', textShadow: '0 0 8px #7fdb6a', letterSpacing: '0.06em' }}>
          {title.toUpperCase().replace(/ /g, '_')}
        </div>
      ) : isPage ? (
        <div style={{ fontFamily: '"Tangerine","Italianno",cursive', fontSize: 42, color: '#742818', lineHeight: 1, fontStyle: 'italic' }}>{title}</div>
      ) : (
        <div style={{ fontFamily: '"Inter Tight",sans-serif', fontSize: 22, fontWeight: 700, color: '#f1ece2', letterSpacing: '-0.02em' }}>{title}</div>
      )}
      {divider && <div style={{ height: 1, background: isPage ? 'rgba(200,152,72,.35)' : (isTerm ? 'rgba(127,219,106,.22)' : 'rgba(255,255,255,.07)'), marginTop: 14 }} />}
    </div>
  );
}

// ─── Stats row ────────────────────────────────────────────────────────────
function StatsRow({ skin, stats }) {
  return (
    <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', marginBottom: 16 }}>
      {stats.map(([l, v, accent]) => (
        <div key={l}>
          <div style={{ ...skin.StatLabelStyle, fontSize: 8, marginBottom: 2 }}>{l}</div>
          <div style={{ ...skin.StatValueStyle, fontSize: accent ? 24 : 16, color: accent ? 'var(--accent)' : 'var(--ink)' }}>{v}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Objectives mini list ─────────────────────────────────────────────────
function ObjList({ skin, items }) {
  const isTerm = skin.id === 'terminal';
  const isPage = skin.id === 'page';
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontFamily: isTerm ? 'var(--font-mono)' : 'var(--font-display)', fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--ink-faint)', marginBottom: 8 }}>Objectives</div>
      {items.map((o, i) => (
        <div key={i} style={{ display: 'flex', gap: 7, alignItems: 'center', marginBottom: 5 }}>
          <span style={{ fontSize: 11, color: o.done ? 'var(--accent)' : 'var(--ink-faint)', flexShrink: 0 }}>{o.done ? (isTerm ? '[✓]' : '✓') : (isTerm ? '[ ]' : '○')}</span>
          <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: o.done ? 'var(--ink-soft)' : 'var(--ink)', textDecoration: o.done ? 'line-through' : 'none', opacity: o.done ? .6 : 1 }}>{o.text}</span>
        </div>
      ))}
    </div>
  );
}

// ─── CTA row ─────────────────────────────────────────────────────────────
function CTARow({ skin, primary, secondary }) {
  return (
    <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
      <span style={{ display: 'inline-flex', cursor: 'pointer' }}><skin.ActionBtn label={primary} kbd="↵" primary /></span>
      {secondary && <span style={{ display: 'inline-flex', cursor: 'pointer' }}><skin.ActionBtn label={secondary} compact /></span>}
    </div>
  );
}

// ─── Divider ─────────────────────────────────────────────────────────────
function Divider({ skin }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  return <div style={{ height: 1, background: isPage ? 'rgba(200,152,72,.28)' : (isTerm ? 'rgba(127,219,106,.18)' : 'rgba(255,255,255,.06)'), margin: '14px 0' }} />;
}

// ─── Pause screen ─────────────────────────────────────────────────────────
function PauseScreen({ skin, phone }) {
  return (
    <GameShellFrame skin={skin} phone={phone} boardOpacity={0.22}>
      <PauseCard skin={skin} phone={phone} title="Paused" subtitle="Round 1 · The First Page" />
    </GameShellFrame>
  );
}

// ─── Round complete screen ────────────────────────────────────────────────
function RoundCompleteScreen({ skin, phone }) {
  const objs = [
    { text: 'Spell 5 words', done: true },
    { text: 'Find 3 hidden words', done: false },
    { text: 'Score 500 pts', done: true },
  ];
  return (
    <GameShellFrame skin={skin} phone={phone} boardOpacity={0.14}>
      <FlowCard skin={skin} phone={phone} width={phone ? 300 : 400}>
        <FlowHeader skin={skin} eyebrow="Round Complete" title={skin.id === 'page' ? '"The First Page is set."' : 'The First Page is set.'} />
        <StatsRow skin={skin} stats={[['Score', '240', true], ['Words', '7'], ['Best', 'ARCHIVE +42']]} />
        <ObjList skin={skin} items={objs} />
        <Divider skin={skin} />
        <CTARow skin={skin} primary="Continue" secondary="Settings" />
      </FlowCard>
    </GameShellFrame>
  );
}

// ─── Run complete screen ──────────────────────────────────────────────────
function RunCompleteScreen({ skin, phone }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  const rounds = [
    { name: 'The First Page', score: 240, words: 7 },
    { name: 'The Second Page', score: 310, words: 9 },
    { name: 'The Third Page', score: 195, words: 6 },
  ];
  return (
    <GameShellFrame skin={skin} phone={phone} boardOpacity={0.1}>
      <FlowCard skin={skin} phone={phone} width={phone ? 308 : 440}>
        <FlowHeader skin={skin} eyebrow="Volume i, complete" title={isPage ? '"A word puzzle, finished."' : 'Volume i, complete.'} />
        <StatsRow skin={skin} stats={[['Total Score', '745', true], ['Words Found', '22'], ['Best Word', 'ARCHIVE']]} />
        {!phone && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ fontFamily: isTerm ? 'var(--font-mono)' : 'var(--font-display)', fontSize: 9, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--ink-faint)', marginBottom: 8 }}>Rounds</div>
            {rounds.map((r, i) => (
              <div key={i} style={{
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '6px 0',
                borderBottom: `1px solid ${isPage ? 'rgba(200,152,72,.18)' : (isTerm ? 'rgba(127,219,106,.1)' : 'rgba(255,255,255,.04)')}`,
              }}>
                <span style={{ fontFamily: 'var(--font-body)', fontSize: 12, color: 'var(--ink-soft)', fontStyle: isPage ? 'italic' : 'normal' }}>{r.name}</span>
                <div style={{ display: 'flex', gap: 12 }}>
                  <span style={{ ...skin.StatValueStyle, fontSize: 13, color: 'var(--ink)' }}>{r.score}</span>
                  <span style={{ fontFamily: 'var(--font-body)', fontSize: 11, color: 'var(--ink-faint)' }}>{r.words} words</span>
                </div>
              </div>
            ))}
          </div>
        )}
        <Divider skin={skin} />
        <CTARow skin={skin} primary="New Run" secondary="Quit to Title" />
      </FlowCard>
    </GameShellFrame>
  );
}

// ─── Settings comp ────────────────────────────────────────────────────────
// Skin-aware settings screen. No live state — static comp.

function SegCtrl({ skin, options, selected, disabled }) {
  return (
    <div style={{
      display: 'flex', border: '1px solid var(--rule-faint)',
      opacity: disabled ? 0.45 : 1,
    }}>
      {options.map((o, i) => (
        <div key={o} style={{
          padding: '4px 10px', fontSize: 12,
          background: o === selected ? 'var(--accent)' : 'transparent',
          color: o === selected ? 'var(--surface)' : 'var(--ink-soft)',
          borderRight: i < options.length - 1 ? '1px solid var(--rule-faint)' : 'none',
          fontFamily: 'var(--font-display)', fontWeight: o === selected ? 600 : 400,
          cursor: disabled ? 'default' : 'pointer', whiteSpace: 'nowrap',
        }}>{o}</div>
      ))}
    </div>
  );
}

function ToggleCtrl({ skin, on, disabled }) {
  return (
    <div style={{
      width: 38, height: 20, borderRadius: 10, position: 'relative',
      background: on ? 'var(--accent)' : 'var(--rule-faint)',
      border: '1px solid var(--rule-faint)',
      opacity: disabled ? 0.45 : 1, flexShrink: 0,
    }}>
      <div style={{
        position: 'absolute', top: 2, left: on ? 18 : 2,
        width: 14, height: 14, borderRadius: '50%', background: 'var(--surface)',
      }} />
    </div>
  );
}

function SettingRow({ skin, label, desc, control }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
      padding: '11px 0', borderBottom: '1px dotted var(--rule-faint)',
    }}>
      <div style={{ flex: 1, paddingRight: 14 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 14, fontWeight: 500, color: 'var(--ink)' }}>{label}</div>
        {desc && <div style={{ fontStyle: skin.id === 'page' ? 'italic' : 'normal', fontSize: 11, color: 'var(--ink-soft)', marginTop: 2, lineHeight: 1.4 }}>{desc}</div>}
      </div>
      <div style={{ flexShrink: 0, paddingTop: 2 }}>{control}</div>
    </div>
  );
}

function SkinThumb({ skin, thisSkin, selected }) {
  const isSelected = selected;
  return (
    <div style={{
      ...thisSkin.vars,
      border: isSelected ? '2px solid var(--accent)' : '1px solid var(--rule-faint)',
      cursor: 'pointer', position: 'relative', overflow: 'hidden',
    }}>
      <div style={{ position: 'relative', width: '100%', height: 100, background: 'var(--bg)', overflow: 'hidden' }}>
        <thisSkin.Background />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
          <thisSkin.RoundBadge round="I" />
          <div style={{ fontFamily: thisSkin.HeadingFont, fontSize: 11, fontWeight: 600, color: thisSkin.id === 'page' ? '#7a4a28' : 'var(--ink)' }}>
            {thisSkin.HeadingTransform('The First Page')}
          </div>
          {/* Mini 3×2 board snippet */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            {[['A','R','C'],['H','I','V']].map((row, r) => (
              <div key={r} style={{ display: 'flex', gap: 1 }}>
                {row.map((ch, c) => (
                  <div key={c} style={{
                    ...thisSkin.vars,
                    width: 18, height: 18,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontFamily: 'var(--font-display)', fontSize: 9, fontWeight: 600,
                    color: r === 0 ? 'var(--tile-on-color)' : 'var(--ink)',
                    background: r === 0 ? 'var(--tile-on)' : 'var(--tile-bg)',
                    border: thisSkin.id === 'terminal' ? '1px solid var(--tile-border)' : 'none',
                  }}>{ch}</div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
      <div style={{
        padding: '8px 10px', background: 'var(--surface)',
        borderTop: '1px solid var(--rule-faint)',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <div>
          <div style={{ fontFamily: thisSkin.HeadingFont, fontSize: 12, fontWeight: 600, color: thisSkin.id === 'page' ? '#2a1a10' : (thisSkin.id === 'terminal' ? '#7fdb6a' : '#f1ece2') }}>{thisSkin.name}</div>
          <div style={{ fontSize: 10, color: thisSkin.id === 'page' ? '#5a4030' : (thisSkin.id === 'terminal' ? 'rgba(127,219,106,.5)' : 'rgba(241,236,226,.5)'), fontStyle: thisSkin.id === 'page' ? 'italic' : 'normal', marginTop: 1 }}>{thisSkin.blurb}</div>
        </div>
        {isSelected && (
          <div style={{ width: 18, height: 18, borderRadius: '50%', background: 'var(--accent)', color: 'var(--surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700 }}>✓</div>
        )}
      </div>
    </div>
  );
}

function SkinThumbCompact({ skin, thisSkin, selected }) {
  return (
    <div style={{
      ...thisSkin.vars,
      border: selected ? '2px solid var(--accent)' : '1px solid var(--rule-faint)',
      display: 'flex', alignItems: 'center', gap: 10, padding: 8,
      background: 'var(--surface)', cursor: 'pointer',
    }}>
      <div style={{ position: 'relative', width: 48, height: 34, overflow: 'hidden', background: 'var(--bg)', flexShrink: 0 }}>
        <thisSkin.Background />
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: thisSkin.HeadingFont, fontSize: 18, fontWeight: 700, color: thisSkin.id === 'page' ? '#742818' : (thisSkin.id === 'terminal' ? '#7fdb6a' : '#d4a84a') }}>Aa</div>
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: thisSkin.HeadingFont, fontSize: 13, fontWeight: 600, color: thisSkin.id === 'page' ? '#2a1a10' : (thisSkin.id === 'terminal' ? '#7fdb6a' : '#f1ece2') }}>{thisSkin.name}</div>
        <div style={{ fontSize: 10, color: thisSkin.id === 'page' ? '#5a4030' : (thisSkin.id === 'terminal' ? 'rgba(127,219,106,.5)' : 'rgba(241,236,226,.5)'), fontStyle: thisSkin.id === 'page' ? 'italic' : 'normal' }}>{thisSkin.blurb}</div>
      </div>
      {selected && <div style={{ width: 18, height: 18, borderRadius: '50%', background: 'var(--accent)', color: 'var(--surface)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700 }}>✓</div>}
    </div>
  );
}

function SectionLabel({ skin, children }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  return (
    <div style={{
      fontFamily: isTerm ? 'var(--font-mono)' : (isPage ? '"Tangerine","Italianno",cursive' : '"Inter Tight",sans-serif'),
      fontSize: isTerm ? 10 : (isPage ? 26 : 13),
      fontWeight: isTerm ? 700 : (isPage ? 400 : 700),
      color: isPage ? '#7a4a28' : (isTerm ? 'rgba(127,219,106,.55)' : 'rgba(212,168,74,.7)'),
      letterSpacing: isTerm ? '0.2em' : (isPage ? 0 : '0.08em'),
      textTransform: isTerm ? 'uppercase' : (isPage ? 'none' : 'uppercase'),
      borderBottom: '0.5px dotted var(--rule-faint)',
      paddingBottom: 5, marginBottom: 10,
    }}>{isTerm ? `// ${children.toLowerCase()}` : children}</div>
  );
}

function SettingsDesktopComp({ skin, selectedSkinId = 'fullbleed' }) {
  const skins = Object.values(SKINS);
  return (
    <div style={{
      ...skin.vars,
      position: 'relative', width: '100%', height: '100%',
      overflow: 'hidden', background: 'var(--bg)', color: 'var(--ink)',
      fontFamily: 'var(--font-body)',
    }}>
      <skin.Background />
      <div style={{ position: 'absolute', inset: 26, display: 'flex', flexDirection: 'column', zIndex: 1 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 16, paddingBottom: 11, borderBottom: '1px solid var(--rule-faint)' }}>
          <div style={{
            fontFamily: skin.id === 'page' ? '"Tangerine","Italianno",cursive' : (skin.id === 'terminal' ? 'var(--font-mono)' : '"Inter Tight",sans-serif'),
            fontSize: skin.id === 'page' ? 48 : (skin.id === 'terminal' ? 14 : 28),
            fontWeight: skin.id === 'terminal' ? 700 : 600,
            color: skin.id === 'page' ? '#7a4a28' : (skin.id === 'terminal' ? '#7fdb6a' : '#f1ece2'),
            letterSpacing: skin.id === 'terminal' ? '0.18em' : (skin.id === 'page' ? 0 : '-0.02em'),
            textShadow: skin.id === 'terminal' ? '0 0 8px #7fdb6a' : 'none',
          }}>{skin.id === 'terminal' ? '// SETTINGS' : 'Settings'}</div>
          <div style={{ fontStyle: 'italic', fontSize: 12, color: 'var(--ink-faint)', flex: 1 }}>{skin.id === 'page' ? '— preferences for the page' : (skin.id === 'terminal' ? '' : '— preferences')}</div>
          <div style={{ fontStyle: skin.id === 'page' ? 'italic' : 'normal', fontSize: 12, color: 'var(--ink-faint)', cursor: 'pointer', fontFamily: skin.id === 'terminal' ? 'var(--font-mono)' : 'inherit', letterSpacing: skin.id === 'terminal' ? '0.1em' : 0 }}>{skin.id === 'terminal' ? '[ESC] back' : '‹ back'}</div>
        </div>

        {/* Skin picker */}
        <div style={{ marginBottom: 18 }}>
          <SectionLabel skin={skin}>Skin</SectionLabel>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 14 }}>
            {skins.map(s => <SkinThumb key={s.id} skin={skin} thisSkin={s} selected={s.id === selectedSkinId} />)}
          </div>
        </div>

        {/* Two-column settings */}
        <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, minHeight: 0, overflow: 'hidden', alignContent: 'start' }}>
          <div>
            <SectionLabel skin={skin}>Game</SectionLabel>
            <SettingRow skin={skin} label="Difficulty" desc="Balanced mix with some diagonal paths." control={<SegCtrl skin={skin} options={['Easy', 'Medium', 'Hard']} selected="Medium" />} />
            <SettingRow skin={skin} label="Board size" desc="Changes dimensions for the next run." control={<SegCtrl skin={skin} options={['Small', 'Medium', 'Large']} selected="Small" />} />
            <SettingRow skin={skin} label="Goal" desc="How a Word Hunt round ends." control={<SegCtrl skin={skin} options={['Objectives', 'Zen', 'Timed', 'Turns']} selected="Objectives" />} />
            <SettingRow skin={skin} label="Wildcard tile" desc="Acts as any letter. Scores ×0.5." control={<ToggleCtrl skin={skin} on={false} />} />
          </div>
          <div>
            <SectionLabel skin={skin}>Options</SectionLabel>
            <SettingRow skin={skin} label="Sound" desc="Submit, discovery, and interface sounds." control={<ToggleCtrl skin={skin} on={true} />} />
            <SettingRow skin={skin} label="Particles" desc="Board bursts and tile effect particles." control={<ToggleCtrl skin={skin} on={true} />} />

            <div style={{ marginTop: 16 }}>
              <SectionLabel skin={skin}>Coming soon</SectionLabel>
              <SettingRow skin={skin} label="Reduce motion" control={<ToggleCtrl skin={skin} on={false} disabled />} />
              <SettingRow skin={skin} label="Path color" control={<SegCtrl skin={skin} options={['Default', 'Cyan', 'Yellow']} selected="Default" disabled />} />
              <SettingRow skin={skin} label="Dictionary" control={<SegCtrl skin={skin} options={['SOWPODS', 'TWL', 'OSPD']} selected="SOWPODS" disabled />} />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ borderTop: '1px solid var(--rule-faint)', paddingTop: 10, marginTop: 12, fontSize: 11, color: 'var(--ink-faint)', fontStyle: 'italic', fontFamily: skin.id === 'terminal' ? 'var(--font-mono)' : 'var(--font-body)', letterSpacing: skin.id === 'terminal' ? '0.06em' : 0 }}>
          {skin.id === 'terminal' ? '// skin persists; board settings apply on next run' : 'Skin persists on this device · board settings apply on the next run'}
        </div>
      </div>
    </div>
  );
}

function SettingsPhoneComp({ skin, selectedSkinId = 'fullbleed' }) {
  const skins = Object.values(SKINS);
  return (
    <div style={{
      ...skin.vars,
      position: 'relative', width: '100%', height: '100%',
      overflow: 'hidden', background: 'var(--bg)', color: 'var(--ink)',
      fontFamily: 'var(--font-body)',
    }}>
      <skin.Background />
      <div style={{ position: 'absolute', inset: 0, overflow: 'auto', zIndex: 1, padding: 16 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, paddingBottom: 9, borderBottom: '1px solid var(--rule-faint)', marginBottom: 14 }}>
          <div style={{
            fontFamily: skin.id === 'page' ? '"Tangerine","Italianno",cursive' : (skin.id === 'terminal' ? 'var(--font-mono)' : '"Inter Tight",sans-serif'),
            fontSize: skin.id === 'page' ? 36 : (skin.id === 'terminal' ? 12 : 22),
            fontWeight: skin.id === 'terminal' ? 700 : 600,
            color: skin.id === 'page' ? '#7a4a28' : (skin.id === 'terminal' ? '#7fdb6a' : '#f1ece2'),
            textShadow: skin.id === 'terminal' ? '0 0 6px #7fdb6a' : 'none',
          }}>{skin.id === 'terminal' ? '// SETTINGS' : 'Settings'}</div>
          <div style={{ flex: 1 }} />
          <div style={{ fontSize: 12, color: 'var(--ink-faint)', cursor: 'pointer', fontStyle: skin.id === 'page' ? 'italic' : 'normal' }}>‹ back</div>
        </div>

        {/* Skin picker */}
        <div style={{ marginBottom: 14 }}>
          <SectionLabel skin={skin}>Skin</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {skins.map(s => <SkinThumbCompact key={s.id} skin={skin} thisSkin={s} selected={s.id === selectedSkinId} />)}
          </div>
        </div>

        {/* Settings */}
        <div style={{ marginBottom: 14 }}>
          <SectionLabel skin={skin}>Game</SectionLabel>
          <SettingRow skin={skin} label="Difficulty" control={<SegCtrl skin={skin} options={['Easy', 'Med', 'Hard']} selected="Medium" />} />
          <SettingRow skin={skin} label="Board size" control={<SegCtrl skin={skin} options={['S', 'M', 'L']} selected="S" />} />
          <SettingRow skin={skin} label="Goal" control={<SegCtrl skin={skin} options={['Obj', 'Zen', 'Time', 'Turns']} selected="Obj" />} />
          <SettingRow skin={skin} label="Wildcard tile" control={<ToggleCtrl skin={skin} on={false} />} />
          <SettingRow skin={skin} label="Sound" control={<ToggleCtrl skin={skin} on={true} />} />
          <SettingRow skin={skin} label="Particles" control={<ToggleCtrl skin={skin} on={true} />} />
        </div>

        <div style={{ marginBottom: 14 }}>
          <SectionLabel skin={skin}>Coming soon</SectionLabel>
          <SettingRow skin={skin} label="Reduce motion" control={<ToggleCtrl skin={skin} on={false} disabled />} />
          <SettingRow skin={skin} label="Path color" control={<SegCtrl skin={skin} options={['Def', 'Cyan', 'Yel']} selected="Def" disabled />} />
        </div>

        <div style={{ borderTop: '1px solid var(--rule-faint)', paddingTop: 10, fontSize: 11, color: 'var(--ink-faint)', fontStyle: 'italic', fontFamily: skin.id === 'terminal' ? 'var(--font-mono)' : 'var(--font-body)', letterSpacing: skin.id === 'terminal' ? '0.06em' : 0 }}>
          {skin.id === 'terminal' ? '// skin persists; board: next run' : 'Skin persists · board settings apply next run'}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  PauseScreen, RoundCompleteScreen, RunCompleteScreen,
  SettingsDesktopComp, SettingsPhoneComp,
});
