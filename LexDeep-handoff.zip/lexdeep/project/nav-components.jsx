// nav-components.jsx
// Navigation pattern + wildcard tile components for Lexicon Deep design canvas.

// ─── Fake board data ──────────────────────────────────────────────────────
const FAKE_BOARD_ROWS = [
  ['T','R','E','A','S','U','R','E','B','I','N','D'],
  ['S','P','A','R','C','H','M','E','N','T','D','U'],
  ['O','F','F','I','R','E','E','M','B','E','R','G'],
  ['S','H','W','I','N','D','L','A','N','T','E','R'],
  ['A','R','C','H','S','H','A','D','O','W','I','N'],
  ['E','L','L','S','A','B','O','O','K','E','N','D'],
  ['R','I','B','E','S','T','A','R','C','H','I','V'],
  ['A','G','M','E','N','T','V','O','I','D','L','E'],
];
const FAKE_PATH_CELLS = [[2,6],[2,7],[2,8],[2,9],[2,10]]; // E-M-B-E-R

// ─── Mini board ───────────────────────────────────────────────────────────
function MiniBoard({ skin, cellSize = 40, rows, path, opacity = 1 }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  const numCols = rows[0].length;
  const numRows = rows.length;
  const pts = path.map(([r,c]) => [c * cellSize + cellSize/2, r * cellSize + cellSize/2]);
  const pathD = pts.map((p,i) => `${i===0?'M':'L'}${p[0]},${p[1]}`).join(' ');

  return (
    <div style={{ position:'relative', width: numCols*cellSize, height: numRows*cellSize, opacity }}>
      {rows.map((row, r) => (
        <div key={r} style={{ display:'flex' }}>
          {row.map((ch, c) => {
            const onP = path.some(([pr,pc]) => pr===r && pc===c);
            const rot = isPage ? ((r*7+c*13)%7-3)*0.28 : 0;
            return (
              <div key={c} style={{
                width: cellSize, height: cellSize,
                display:'flex', alignItems:'center', justifyContent:'center',
                fontFamily:'var(--font-display)',
                fontSize: cellSize * (isTerm ? 0.52 : 0.48),
                fontWeight: isTerm ? 500 : (isPage ? 500 : 600),
                color: onP ? 'var(--tile-on-color)' : 'var(--ink)',
                background: onP ? 'var(--tile-on)' : 'var(--tile-bg)',
                border: isTerm ? '1px solid var(--tile-border)' : 'none',
                marginLeft: isTerm ? -1 : 0, marginTop: isTerm ? -1 : 0,
                transform: `rotate(${rot}deg)`,
                textShadow: isTerm ? '0 0 4px var(--ink-soft)' : 'none',
                letterSpacing: isPage ? '0.02em' : 0,
                transition: 'background .12s, color .12s',
              }}>{ch}</div>
            );
          })}
        </div>
      ))}
      <svg style={{ position:'absolute', inset:0, width:'100%', height:'100%', pointerEvents:'none' }}>
        {skin.PathRender === 'ink' ? <>
          <path d={pathD} stroke="var(--path-color)" strokeWidth={cellSize*0.4} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.14"/>
          <path d={pathD} stroke="var(--path-color)" strokeWidth={cellSize*0.14} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.88"/>
          {pts.map((p,i) => <circle key={i} cx={p[0]} cy={p[1]} r={cellSize*0.055} fill="var(--path-color)" opacity=".9"/>)}
        </> : <>
          {skin.id==='fullbleed' && <path d={pathD} stroke="var(--accent)" strokeWidth={cellSize*0.05} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.35" filter="blur(2px)"/>}
          <path d={pathD} stroke="var(--path-color)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.9"/>
          {pts.map((p,i) => <circle key={i} cx={p[0]} cy={p[1]} r={cellSize*0.048} fill="var(--path-color)" opacity="0.7"/>)}
        </>}
      </svg>
    </div>
  );
}

// ─── HUD stat ─────────────────────────────────────────────────────────────
function HUDStat({ skin, label, value }) {
  return (
    <div style={{ display:'flex', alignItems:'baseline', gap:5, flexShrink:0 }}>
      <span style={skin.StatLabelStyle}>{label}</span>
      <span style={{ ...skin.StatValueStyle, fontSize:19, color:'var(--ink)', lineHeight:1 }}>{value}</span>
    </div>
  );
}

// ─── Menu button — replaces ? ⚙ ──────────────────────────────────────────
function MenuBtn({ skin, active }) {
  const isTerm = skin.id === 'terminal';
  return (
    <div style={{
      width:36, height:36,
      border: active ? '1px solid var(--accent)' : '1px solid var(--rule-faint)',
      borderRadius: isTerm ? 0 : 999,
      background: active ? 'var(--accent)' : 'transparent',
      color: active ? 'var(--surface)' : 'var(--ink-soft)',
      fontFamily: isTerm ? 'var(--font-mono)' : 'inherit',
      fontSize:17, lineHeight:1,
      display:'inline-flex', alignItems:'center', justifyContent:'center',
      cursor:'pointer',
      letterSpacing:'-0.04em',
      textShadow: isTerm&&!active ? '0 0 5px var(--ink-soft)' : 'none',
      flexShrink:0,
    }}>{active ? '✕' : '≡'}</div>
  );
}

// ─── HUD strip (static comp) ──────────────────────────────────────────────
function FakeHUD({ skin, phone, menuOpen }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  return (
    <div style={{
      display:'flex', alignItems:'center', gap: phone ? 10 : 18,
      padding: phone ? '10px 14px 9px' : '12px 22px',
      borderBottom:'1px solid var(--rule-faint)',
      color:'var(--ink)', position:'relative', zIndex:2,
    }}>
      <skin.RoundBadge round={1}/>
      <div style={{ minWidth:0, flex: phone ? 1 : 'unset' }}>
        <div style={{
          fontFamily: skin.HeadingFont,
          fontSize: phone ? 15 : 19,
          color: isPage ? '#7a4a28' : 'var(--ink)',
          fontWeight: isTerm ? 500 : 600,
          letterSpacing: isPage ? '0.02em' : (isTerm ? '0.1em' : '-0.01em'),
          lineHeight:1.1, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis',
        }}>{skin.HeadingTransform('The First Page')}</div>
        {!phone && (
          <div style={{
            fontSize:11, color:'var(--ink-faint)',
            fontStyle: isPage ? 'italic' : 'normal',
            fontFamily: isTerm ? 'var(--font-mono)' : 'var(--font-body)',
            marginTop:2, letterSpacing: isTerm ? '0.12em' : 0,
          }}>{isTerm ? '// folio: i_of_iii.dat' : 'folio i of iii'}</div>
        )}
      </div>
      <div style={{ flex: phone ? 'unset' : 1 }}/>
      <HUDStat skin={skin} label="Score" value="240"/>
      {!phone && <HUDStat skin={skin} label="Words" value="07"/>}
      <HUDStat skin={skin} label="Clues" value="3"/>
      <HUDStat skin={skin} label="Time" value="4:13"/>
      <MenuBtn skin={skin} active={menuOpen}/>
    </div>
  );
}

// ─── Right rail ───────────────────────────────────────────────────────────
function FakeRightRail({ skin }) {
  const isTerm = skin.id === 'terminal';
  const isPage = skin.id === 'page';
  const objs = [
    { text:'Spell 5 words', done:true },
    { text:'Find 3 hidden words', done:false },
    { text:'Score 500 pts', done:false },
  ];
  const recent = [
    { word:'ARCHIVE', score:42 },
    { word:'LANTERN', score:28 },
    { word:'SHADOW', score:18 },
  ];
  const labelStyle = {
    fontFamily: isTerm?'var(--font-mono)':'var(--font-display)',
    fontSize:9, letterSpacing:'0.18em', textTransform:'uppercase',
    color:'var(--ink-faint)', marginBottom:8, display:'block',
  };
  return (
    <div style={{
      width:200, borderLeft:'1px solid var(--rule-faint)',
      padding:'14px 12px', display:'flex', flexDirection:'column', gap:14,
    }}>
      <div>
        <span style={labelStyle}>Objectives</span>
        {objs.map((o,i) => (
          <div key={i} style={{ display:'flex', gap:6, alignItems:'flex-start', marginBottom:5 }}>
            <span style={{ fontSize:11, color: o.done?'var(--accent)':'var(--ink-faint)', flexShrink:0, marginTop:1 }}>{o.done?(isTerm?'[✓]':'✓'):(isTerm?'[ ]':'○')}</span>
            <span style={{ fontFamily:'var(--font-body)', fontSize:12, color: o.done?'var(--ink-soft)':'var(--ink)', textDecoration: o.done?'line-through':'none', opacity: o.done?.65:1 }}>{o.text}</span>
          </div>
        ))}
      </div>
      <div style={{ borderTop:'1px solid var(--rule-faint)', paddingTop:12 }}>
        <span style={labelStyle}>Recent</span>
        {recent.map((r,i) => (
          <div key={i} style={{ display:'flex', justifyContent:'space-between', marginBottom:4 }}>
            <span style={{ fontFamily:'var(--font-body)', fontSize:12, color:'var(--ink)' }}>{r.word}</span>
            <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:'var(--accent)', opacity:.75 }}>{r.score}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Action bar ───────────────────────────────────────────────────────────
function FakeActionBar({ skin, phone }) {
  return (
    <div style={{
      borderTop:'1px solid var(--rule-faint)',
      padding: phone ? '10px 14px' : '10px 22px',
      display:'flex', alignItems:'center', gap:12,
    }}>
      <div style={{
        fontFamily:'var(--font-display)',
        fontSize: phone ? 24 : 30,
        fontWeight: skin.id==='terminal' ? 500 : 600,
        color:'var(--ink)', flex:1,
        letterSpacing: skin.id==='terminal' ? '0.18em' : '0.04em',
        textShadow: skin.id==='terminal' ? '0 0 8px var(--ink-soft)' : 'none',
      }}>EMBER</div>
      <div style={{ display:'flex', gap:8 }}>
        <span style={{display:'inline-flex'}}><skin.ActionBtn label="Submit" kbd="↵" primary/></span>
        <span style={{display:'inline-flex'}}><skin.ActionBtn label="Clear" kbd="⌫" compact/></span>
        <span style={{display:'inline-flex'}}><skin.ActionBtn label="Undo" kbd="Z" compact/></span>
      </div>
    </div>
  );
}

// ─── Page corner ornament ─────────────────────────────────────────────────
function CornerOrn({ style }) {
  return (
    <svg width="22" height="22" viewBox="0 0 36 36" style={{ position:'absolute', ...style }}>
      <g stroke="#c89848" strokeWidth="0.9" fill="none">
        <path d="M2 18 Q 2 2 18 2"/><path d="M6 18 Q 6 6 18 6"/>
        <circle cx="6" cy="6" r="1.4" fill="#c89848"/>
      </g>
    </svg>
  );
}

// ─── Pause menu card ──────────────────────────────────────────────────────
const NAV_ITEMS = [
  { label:'Resume',       icon:'▶', kbd:'Esc', primary:true },
  { label:'Settings',     icon:'⚙', kbd:'S' },
  { label:'How to Play',  icon:'?', kbd:'H' },
  { label:'Restart Run',  icon:'↺', kbd:'R' },
  { label:'Quit to Title',icon:'✕', kbd:'Q' },
];

function PauseCard({ skin, phone, title='Paused', subtitle='Round 1 · The First Page', showScore=true }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  const cardW = phone ? 288 : 328;

  return (
    <div style={{
      width: cardW,
      background: isPage
        ? 'radial-gradient(ellipse at 30% 20%, #f9f0d8 0%, #f3e9d2 55%, #e8dcbe 100%)'
        : isTerm ? '#0a0d09' : '#12141a',
      border: isPage ? '1px solid rgba(200,152,72,.5)' : (isTerm ? '1px solid #7fdb6a' : '1px solid rgba(255,255,255,.09)'),
      boxShadow: '0 12px 48px rgba(0,0,0,.75), 0 2px 8px rgba(0,0,0,.4)',
      borderRadius: isTerm ? 0 : 4,
      position:'relative', overflow:'hidden',
    }}>
      {/* Page corners */}
      {isPage && <>
        <CornerOrn style={{ top:8,left:8 }}/>
        <CornerOrn style={{ top:8,right:8, transform:'scaleX(-1)' }}/>
        <CornerOrn style={{ bottom:8,left:8, transform:'scaleY(-1)' }}/>
        <CornerOrn style={{ bottom:8,right:8, transform:'scale(-1,-1)' }}/>
      </>}
      {/* Terminal scanline */}
      {isTerm && <div style={{ position:'absolute', inset:0, background:'repeating-linear-gradient(to bottom, rgba(127,219,106,0) 0px, rgba(127,219,106,0) 2px, rgba(0,0,0,.15) 2px, rgba(0,0,0,.15) 3px)', opacity:.5, pointerEvents:'none' }}/>}

      <div style={{ position:'relative', zIndex:1, padding: isTerm ? '18px 18px' : '22px 26px' }}>
        {/* Header */}
        <div style={{ marginBottom:18 }}>
          {isTerm ? (
            <div style={{ fontFamily:'var(--font-mono)', fontSize:12, fontWeight:700, color:'#7fdb6a', letterSpacing:'0.2em', textShadow:'0 0 6px #7fdb6a' }}>▐ PAUSED ▌</div>
          ) : isPage ? (
            <div style={{ fontFamily:'"Tangerine","Italianno",cursive', fontSize:38, color:'#742818', lineHeight:1 }}>{title}</div>
          ) : (
            <div style={{ fontFamily:'"Inter Tight",sans-serif', fontSize:17, fontWeight:700, color:'#f1ece2', letterSpacing:'-0.02em' }}>{title}</div>
          )}
          {subtitle && (
            <div style={{
              fontSize:11, marginTop:3,
              color: isTerm?'rgba(127,219,106,.45)':(isPage?'#5a4030':'rgba(241,236,226,.38)'),
              fontStyle: isPage?'italic':'normal',
              fontFamily: isTerm?'var(--font-mono)':'var(--font-body)',
              letterSpacing: isTerm?'0.08em':0,
            }}>{isTerm ? `// ${subtitle.toLowerCase().replace(/[^a-z0-9·]+/g,'_')}` : subtitle}</div>
          )}
          <div style={{ height:1, background: isPage?'rgba(200,152,72,.38)':(isTerm?'rgba(127,219,106,.22)':'rgba(255,255,255,.07)'), marginTop:13 }}/>
        </div>

        {/* Items */}
        <div style={{ display:'flex', flexDirection:'column', gap: isTerm?0:2 }}>
          {NAV_ITEMS.map((item, i) => {
            const isPrimary = item.primary;
            return (
              <div key={i} style={{
                display:'flex', alignItems:'center', gap:11,
                padding: isTerm ? '8px 2px' : '9px 8px',
                borderRadius: isTerm ? 0 : 3,
                background: isPrimary ? (isPage?'rgba(116,40,24,.07)':'rgba(212,168,74,.05)') : 'transparent',
                borderBottom: isTerm ? '1px solid rgba(127,219,106,.1)' : 'none',
                cursor:'pointer',
              }}>
                {isTerm ? (
                  <span style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'rgba(127,219,106,.5)', letterSpacing:'0.06em', width:32, flexShrink:0 }}>[{item.kbd}]</span>
                ) : (
                  <span style={{ fontSize:13, width:18, textAlign:'center', color: isPrimary?'var(--accent)':'var(--ink-soft)', opacity: isPrimary?1:.55, flexShrink:0 }}>{item.icon}</span>
                )}
                <span style={{
                  flex:1,
                  fontFamily: isTerm?'var(--font-mono)':(isPage?'"EB Garamond",serif':'"Inter Tight",sans-serif'),
                  fontSize: isTerm?12:(isPage?15:14),
                  fontWeight: isPrimary ? 600 : (isPage?400:400),
                  fontStyle: isPage&&!isPrimary ? 'italic' : 'normal',
                  color: isTerm ? (isPrimary?'#7fdb6a':'rgba(127,219,106,.75)') : (isPrimary?(isPage?'#742818':'#d4a84a'):'var(--ink)'),
                  textShadow: isTerm&&isPrimary ? '0 0 6px #7fdb6a' : 'none',
                  letterSpacing: isTerm?'0.08em':0,
                }}>{isTerm ? item.label.toUpperCase() : item.label}</span>
                {!isTerm && (
                  <span style={{
                    fontFamily:'"IBM Plex Mono",monospace', fontSize:9,
                    color: isPage?'rgba(90,64,48,.3)':'rgba(241,236,226,.18)',
                    padding:'1px 5px',
                    border:`1px solid ${isPage?'rgba(200,152,72,.22)':'rgba(255,255,255,.06)'}`,
                    borderRadius:2, flexShrink:0,
                  }}>{item.kbd}</span>
                )}
              </div>
            );
          })}
        </div>

        {/* Score footer */}
        {showScore && (
          <div style={{
            marginTop:16,
            borderTop:`1px solid ${isPage?'rgba(200,152,72,.28)':(isTerm?'rgba(127,219,106,.18)':'rgba(255,255,255,.06)')}`,
            paddingTop:12, display:'flex', gap:18,
          }}>
            {[['Score','240'],['Round','1/3'],['Words','7']].map(([l,v]) => (
              <div key={l} style={{ display:'flex', flexDirection:'column', gap:2 }}>
                <span style={{ ...skin.StatLabelStyle, fontSize:8 }}>{l}</span>
                <span style={{ ...skin.StatValueStyle, fontSize:13, color:'var(--ink)' }}>{v}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Full artboard: game view with menu card open ─────────────────────────
function NavArtboard({ skin, phone }) {
  const boardCols = phone ? 7 : 10;
  const cellSize = phone ? 36 : 42;
  const fakeRows = FAKE_BOARD_ROWS.slice(0,8).map(r => r.slice(0, boardCols));
  const fakePath = FAKE_PATH_CELLS.filter(([,c]) => c < boardCols);

  return (
    <div style={{
      ...skin.vars,
      position:'relative', width:'100%', height:'100%',
      overflow:'hidden', background:'var(--bg)', color:'var(--ink)',
      fontFamily:'var(--font-body)', display:'flex', flexDirection:'column',
    }}>
      <skin.Background/>
      <div style={{ position:'relative', zIndex:1, display:'flex', flexDirection:'column', height:'100%' }}>
        <FakeHUD skin={skin} phone={phone} menuOpen={true}/>
        <div style={{ flex:1, display:'flex', minHeight:0, position:'relative' }}>
          <div style={{ flex:1, display:'flex', alignItems:'center', justifyContent:'center' }}>
            <MiniBoard skin={skin} cellSize={cellSize} rows={fakeRows} path={fakePath} opacity={0.3}/>
          </div>
          {!phone && <FakeRightRail skin={skin}/>}
        </div>
        <FakeActionBar skin={skin} phone={phone}/>

        {/* Overlay */}
        <div style={{
          position:'absolute', inset:0, zIndex:10,
          background:'rgba(0,0,0,.62)',
          display:'flex', alignItems:'center', justifyContent:'center',
          backdropFilter:'blur(2px)',
        }}>
          <PauseCard skin={skin} phone={phone}/>
        </div>
      </div>
    </div>
  );
}

// ─── Wildcard tile sample ─────────────────────────────────────────────────
function WildcardSample({ skin }) {
  const isPage = skin.id === 'page';
  const isTerm = skin.id === 'terminal';
  const size = 46;
  // Path: S-T-✦-R-S where ✦ stands for A → STARS
  const tiles = ['S','T','✦','R','S'];
  const wildIdx = 2;
  const pathW = tiles.length * size + (tiles.length - 1) * 3;

  return (
    <div style={{
      ...skin.vars,
      background:'var(--bg)', position:'relative', overflow:'hidden',
      padding:'18px 18px 16px',
    }}>
      <skin.Background/>
      <div style={{ position:'relative', zIndex:1 }}>
        <div style={{
          fontFamily: isTerm?'var(--font-mono)':'"Inter Tight",sans-serif',
          fontSize:10, letterSpacing:'0.2em', textTransform:'uppercase',
          color: isPage?'rgba(90,64,48,.5)':(isTerm?'rgba(127,219,106,.45)':'rgba(241,236,226,.35)'),
          marginBottom:12,
        }}>{skin.name}</div>

        {/* Tiles */}
        <div style={{ display:'flex', gap:3, marginBottom:14, position:'relative', width:pathW }}>
          {tiles.map((ch, i) => {
            const isWild = i === wildIdx;
            const accent = isPage?'#c89848':(isTerm?'#7fdb6a':'#d4a84a');
            return (
              <div key={i} style={{
                width:size, height:size, flexShrink:0,
                display:'flex', alignItems:'center', justifyContent:'center',
                fontFamily:'var(--font-display)',
                fontSize: size * (isWild ? 0.55 : 0.48),
                fontWeight: isTerm?500:600,
                color: isWild ? accent : 'var(--tile-on-color)',
                background: isWild ? 'transparent' : 'var(--tile-on)',
                border: isWild
                  ? `1.5px dashed ${isPage?'rgba(200,152,72,.65)':(isTerm?'rgba(127,219,106,.55)':'rgba(212,168,74,.5)')}`
                  : (isTerm?'1px solid var(--tile-border)':'none'),
                borderRadius: isTerm?0:2,
                textShadow: isTerm?'0 0 8px currentColor':'none',
                position:'relative',
              }}>
                {ch}
                {isWild && (
                  <div style={{
                    position:'absolute', inset:4,
                    borderRadius: isTerm?0:'50%',
                    border:`1px solid ${isPage?'rgba(200,152,72,.2)':(isTerm?'rgba(127,219,106,.12)':'rgba(212,168,74,.15)')}`,
                    pointerEvents:'none',
                  }}/>
                )}
              </div>
            );
          })}
          {/* Path line */}
          <svg style={{ position:'absolute', inset:0, width:pathW, height:size, pointerEvents:'none' }}>
            {(() => {
              const pts = tiles.map((_,i) => [i*(size+3)+size/2, size/2]);
              const d = pts.map((p,i) => `${i===0?'M':'L'}${p[0]},${p[1]}`).join(' ');
              return skin.PathRender==='ink' ? <>
                <path d={d} stroke="var(--path-color)" strokeWidth={size*0.38} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.12"/>
                <path d={d} stroke="var(--path-color)" strokeWidth={size*0.12} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.8"/>
              </> : <>
                {skin.id==='fullbleed'&&<path d={d} stroke="var(--accent)" strokeWidth={size*0.05} strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.3" filter="blur(2px)"/>}
                <path d={d} stroke="var(--path-color)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.8"/>
              </>;
            })()}
          </svg>
        </div>

        {/* Word formed */}
        <div style={{
          fontFamily:'var(--font-display)', fontSize:13,
          color:'var(--ink)', letterSpacing: isTerm?'0.14em':'0.04em',
          fontStyle: isPage?'italic':'normal', marginBottom:5,
        }}>
          ST✦RS &rarr; <strong>STARS</strong>
        </div>
        <div style={{
          fontFamily: isTerm?'var(--font-mono)':'var(--font-body)', fontSize:11,
          color: isPage?'rgba(90,64,48,.5)':(isTerm?'rgba(127,219,106,.38)':'rgba(241,236,226,.32)'),
          fontStyle: isPage?'italic':'normal',
          letterSpacing: isTerm?'0.08em':0,
        }}>
          {isTerm ? '// score ×0.5 — wildcard penalty' : 'score ×0.5 · wildcard penalty'}
        </div>
      </div>
    </div>
  );
}

// ─── Rationale card (yellow sticky-ish) ───────────────────────────────────
function RationaleCard({ title, children }) {
  return (
    <div style={{
      background:'#fefae6', border:'1px solid #e0cc70',
      padding:'16px 18px', fontFamily:'"EB Garamond",Georgia,serif',
      fontSize:13.5, lineHeight:1.6, color:'#3a2a08',
      boxShadow:'0 2px 8px rgba(0,0,0,.09)',
    }}>
      <div style={{ fontWeight:700, fontSize:12, letterSpacing:'0.14em', textTransform:'uppercase', marginBottom:8, color:'#7a5a18', fontFamily:'"Inter Tight",sans-serif' }}>{title}</div>
      <div style={{ fontStyle:'italic' }}>{children}</div>
    </div>
  );
}

Object.assign(window, {
  MiniBoard, FakeHUD, FakeRightRail, FakeActionBar,
  NavArtboard, PauseCard, WildcardSample, RationaleCard,
  FAKE_BOARD_ROWS, FAKE_PATH_CELLS,
});
